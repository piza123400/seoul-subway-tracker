@echo off

REM npm 프로젝트 실행 (PowerShell)
start powershell -NoExit -Command "cd 'C:\Users\USER\Desktop\seoul-subway-tracker-main\backend'; npm start"

REM python 서버 실행 (PowerShell)
start powershell -NoExit -Command "cd 'C:\Users\USER\Desktop\seoul-subway-tracker-main\frontend'; python -m http.server 8000"

exit