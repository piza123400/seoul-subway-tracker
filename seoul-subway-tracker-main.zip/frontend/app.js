// ========================================
// 서울 지하철 실시간 추적 시스템 - 프론트엔드
// ========================================

const API_BASE = 'http://localhost:3000';

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', () => {
  console.log('🚇 서울 지하철 추적 시스템 시작됨');
  initializeApp();
  loadRealTimeData();
  
  // 3초마다 실시간 데이터 업데이트
  setInterval(loadRealTimeData, 3000);
});

/**
 * 앱 초기화
 * - 노선 필터 버튼 생성
 * - 이벤트 리스너 등록
 */
async function initializeApp() {
  try {
    // 노선 목록
    const lines = [
      { id: '1001', name: '1호선' },
      { id: '1002', name: '2호선' },
      { id: '1003', name: '3호선' },
      { id: '1004', name: '4호선' },
      { id: '1005', name: '5호선' },
      { id: '1006', name: '6호선' },
      { id: '1007', name: '7호선' },
      { id: '1008', name: '8호선' },
      { id: '1009', name: '9호선' }
    ];

    // 노선 필터 버튼 생성
    const filterContainer = document.getElementById('lineFilter');
    lines.forEach(line => {
      const btn = document.createElement('button');
      btn.textContent = line.name;
      btn.className = 'line-btn';
      btn.onclick = () => filterByLine(line.id);
      filterContainer.appendChild(btn);
    });

    // 이벤트 리스너 등록
    document.getElementById('searchBtn').addEventListener('click', searchStations);
    document.getElementById('searchInput').addEventListener('keypress', (e) => {
      if (e.key === 'Enter') searchStations();
    });
    document.getElementById('resetBtn').addEventListener('click', resetSearch);

    console.log('✅ 앱 초기화 완료');
  } catch (err) {
    console.error('❌ 앱 초기화 오류:', err);
  }
}

/**
 * 실시간 지하철 도착정보 로드
 * 서울 공개데이터 API에서 가져온 실제 도착정보 표시
 */
async function loadRealTimeData() {
  try {
    const response = await fetch(`${API_BASE}/api/realtime?limit=10`);
    if (!response.ok) throw new Error('데이터를 불러올 수 없습니다');
    
    const result = await response.json();
    
    if (result.success && result.data) {
      displayRealTimeData(result.data);
    } else {
      throw new Error('올바르지 않은 응답 형식입니다');
    }
  } catch (err) {
    console.error('❌ 실시간 데이터 로드 오류:', err);
    document.getElementById('subwayInfo').innerHTML = 
      '<p class="error-msg">⚠️ 데이터를 불러올 수 없습니다</p>';
  }
}

/**
 * 실시간 도착정보 표시
 * @param {Array} data - 도착정보 배열
 */
function displayRealTimeData(data) {
  const container = document.getElementById('subwayInfo');
  
  if (data.length === 0) {
    container.innerHTML = '<p class="info-placeholder">조회 가능한 데이터가 없습니다</p>';
    return;
  }

  container.innerHTML = data.map(train => {
    // 도착 시간을 읽기 좋은 형식으로 변환
    let arrivalTime = '진입중';
    if (train.barvlDt > 0) {
      const minutes = Math.floor(train.barvlDt / 60);
      const seconds = train.barvlDt % 60;
      if (minutes > 0) {
        arrivalTime = `${minutes}분 ${seconds}초`;
      } else {
        arrivalTime = `${seconds}초`;
      }
    }

    return `
      <div class="train-card">
        <div class="train-header">
          <span class="line-badge">${train.statnNm}</span>
          <span class="direction-badge">${train.updnLine}</span>
        </div>
        <div class="train-body">
          <p><strong>노선:</strong> ${train.trainLineNm}</p>
          <p><strong>상태:</strong> ${train.arvlMsg2}</p>
          <p><strong>도착까지:</strong> <span class="arrival-time">${arrivalTime}</span></p>
          <p><strong>열차번호:</strong> ${train.btrainNo}</p>
        </div>
        <div class="train-footer">
          <small>${train.recptnDt}</small>
        </div>
      </div>
    `;
  }).join('');

  console.log(`📡 실시간 도착정보 업데이트: ${data.length}개 항목`);
}

/**
 * 역 검색
 * 입력된 역 이름으로 검색
 */
async function searchStations() {
  const query = document.getElementById('searchInput').value.trim();
  
  if (!query) {
    alert('역 이름을 입력하세요');
    return;
  }

  try {
    const response = await fetch(`${API_BASE}/api/stations?name=${encodeURIComponent(query)}`);
    const result = await response.json();
    
    if (result.success && result.data.length > 0) {
      displayStationInfo(result.data);
      console.log(`🔍 검색 결과: "${query}" - ${result.data.length}개 역 발견`);
    } else {
      document.getElementById('stationInfo').innerHTML = 
        `<p class="info-placeholder">검색 결과 없음: "${query}"</p>`;
      console.log(`⚠️ 검색 결과 없음: "${query}"`);
    }
  } catch (err) {
    console.error('❌ 역 검색 오류:', err);
    document.getElementById('stationInfo').innerHTML = 
      '<p class="error-msg">⚠️ 검색 중 오류가 발생했습니다</p>';
  }
}

/**
 * 노선별 필터링
 * @param {string} lineId - 노선 ID
 */
async function filterByLine(lineId) {
  try {
    const response = await fetch(`${API_BASE}/api/stations?line=${lineId}`);
    const result = await response.json();
    
    if (result.success && result.data.length > 0) {
      displayStationInfo(result.data);
      console.log(`📍 ${result.data[0].line_name} 역 조회: ${result.data.length}개`);
    }
  } catch (err) {
    console.error('❌ 노선 필터링 오류:', err);
  }
}

/**
 * 역 정보 표시
 * @param {Array} stations - 역 정보 배열
 */
function displayStationInfo(stations) {
  const container = document.getElementById('stationInfo');
  
  container.innerHTML = stations.map(station => `
    <div class="station-card">
      <div class="station-name">${station.station_name}</div>
      <div class="station-line">${station.line_name}</div>
      <div class="station-id">역 ID: ${station.station_id}</div>
    </div>
  `).join('');
}

/**
 * 검색 초기화
 * 입력값과 검색 결과 초기화
 */
function resetSearch() {
  document.getElementById('searchInput').value = '';
  document.getElementById('stationInfo').innerHTML = 
    '<p class="info-placeholder">검색 또는 역을 선택하세요</p>';
  loadRealTimeData();
  console.log('🔄 검색 초기화 완료');
}