'use strict';

// node-fetch 가져오기 (올바른 방식)
const fetch = require('node-fetch');
const xml2js = require('xml2js');

// 서울 공개데이터 API 설정
const SEOUL_API_BASE = 'http://swopenAPI.seoul.go.kr/api/subway';
const API_KEY = process.env.SEOUL_API_KEY;

/**
 * 실시간 지하철 도착정보 조회
 * @param {number} limit - 조회할 데이터 개수 (기본값: 100)
 * @returns {Promise<Array>} 도착정보 배열
 */
async function getRealTimeArrival(limit = 100) {
  try {
    // API 키 확인
    if (!API_KEY) {
      throw new Error('API 키가 설정되지 않았습니다. .env 파일을 확인하세요.');
    }

    // 페이징 설정
    const START_INDEX = 1;
    const END_INDEX = Math.min(limit, 100); // 최대 100개까지만 조회 가능

    // 서울 공개데이터 API 요청
    const url = `${SEOUL_API_BASE}/${API_KEY}/xml/realtimeStationArrival/ALL/${START_INDEX}/${END_INDEX}`;
    console.log('실시간 도착정보 API 요청:', url.replace(API_KEY, '***'));

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP 오류: ${response.status}`);
    }

    const xmlData = await response.text();

    // XML을 JSON으로 변환
    const parser = new xml2js.Parser();
    const result = await parser.parseStringPromise(xmlData);

    // 응답 상태 확인
    if (!result.realtimeStationArrival || !result.realtimeStationArrival.RESULT) {
      throw new Error('올바르지 않은 API 응답 형식입니다');
    }

    const resultCode = result.realtimeStationArrival.RESULT[0].code[0];
    if (resultCode !== 'INFO-000') {
      const message = result.realtimeStationArrival.RESULT[0].message[0];
      throw new Error(`서울 공개데이터 API 오류: ${message}`);
    }

    // 데이터 형식 변환
    const rows = result.realtimeStationArrival.row || [];
    const trains = rows.map(row => ({
      subwayId: row.subwayId[0],
      statnNm: row.statnNm[0],
      trainLineNm: row.trainLineNm[0],
      barvlDt: parseInt(row.barvlDt[0], 10), // 도착까지 시간 (초)
      updnLine: row.updnLine[0] === '0' ? '상행' : '하행', // 상/하행 변환
      arvlMsg2: row.arvlMsg2[0],
      arvlMsg3: row.arvlMsg3[0],
      btrainNo: row.btrainNo[0],
      recptnDt: row.recptnDt[0],
      lstcarAt: row.lstcarAt[0] === '1' ? '막차' : '' // 막차 여부
    }));

    console.log(`실시간 도착정보 조회 완료: ${trains.length}개 항목`);
    return trains;
  } catch (err) {
    console.error('실시간 도착정보 조회 오류:', err.message);
    throw err;
  }
}

module.exports = { getRealTimeArrival };