'use strict';

const path = require('path');
const fs = require('fs');

// 역 데이터 파일 로드
const filePath = path.join(__dirname, '../../data/stations.json');
const stations = JSON.parse(fs.readFileSync(filePath, 'utf8')).stations;

/**
 * 모든 역 조회
 * @returns {Array} 전체 역 목록
 */
function getAll() {
  return stations;
}

/**
 * 노선 ID로 역 필터링
 * @param {string} subwayId - 노선 ID (예: 1001)
 * @returns {Array} 해당 노선의 역 목록
 */
function getByLine(subwayId) {
  return stations.filter(s => s.subway_id === String(subwayId));
}

/**
 * 역 이름으로 검색
 * @param {string} name - 검색할 역 이름 (한글)
 * @returns {Array} 검색 결과 역 목록
 */
function getByName(name) {
  const query = name.trim();
  return stations.filter(s => s.station_name.includes(query));
}

module.exports = { getAll, getByLine, getByName };