'use strict';

// 환경 변수 로드
require('dotenv').config();
const app = require('./app');

// 포트 설정
const PORT = process.env.PORT || 3000;

// 서버 시작
app.listen(PORT, () => {
  console.log(`⭐ 서울 지하철 실시간 추적 시스템 시작됨`);
  console.log(`🌐 백엔드 서버: http://localhost:${PORT}`);
  console.log(`📡 API 문서: http://localhost:${PORT}/`);
  console.log(`🚀 프론트엔드: http://localhost:8000`);
  console.log(`💡 Ctrl+C 를 눌러 서버를 종료하세요`);
});