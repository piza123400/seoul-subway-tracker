'use strict';

const express = require('express');
const cors = require('cors');
const stationService = require('./services/stationService');
const realTimeService = require('./services/realTimeService');

const app = express();

// ========================================
// 미들웨어 설정
// ========================================

// CORS 미들웨어 - 프론트엔드와의 통신 허용
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:8000'
}));

// JSON 요청 바디 파싱
app.use(express.json());

// ========================================
// API 엔드포인트
// ========================================

/**
 * GET /api/stations
 * 지하철 역 조회
 * 
 * 쿼리 파라미터:
 *   ?line=1001   – 노선 ID로 필터링
 *   ?name=강남   – 역 이름으로 검색 (한글)
 */
app.get('/api/stations', (req, res) => {
  try {
    const { line, name } = req.query;

    if (line) {
      return res.json({ success: true, data: stationService.getByLine(line) });
    }
    if (name) {
      return res.json({ success: true, data: stationService.getByName(name) });
    }
    return res.json({ success: true, data: stationService.getAll() });
  } catch (err) {
    console.error('/api/stations 오류 발생:', err);
    return res.status(500).json({ success: false, message: '서버 내부 오류' });
  }
});

/**
 * GET /api/realtime
 * 실시간 지하철 도착정보 조회
 * 
 * 서울 공개데이터 API에서 가져온 실시간 도착 정보
 * 
 * 쿼리 파라미터:
 *   ?limit=50    – 조회할 데이터 개수 (기본값: 100, 최대: 100)
 */
app.get('/api/realtime', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 100;

    // 입력값 검증
    if (limit < 1 || limit > 100) {
      return res.status(400).json({ 
        success: false, 
        message: '조회 개수는 1~100 사이여야 합니다' 
      });
    }

    // 실시간 도착정보 조회
    const data = await realTimeService.getRealTimeArrival(limit);
    return res.json({ success: true, data });
  } catch (err) {
    console.error('/api/realtime 오류 발생:', err.message);
    
    // 에러 메시지 변환
    let message = '실시간 도착정보를 불러올 수 없습니다';
    if (err.message.includes('API 키')) {
      message = 'API 키가 설정되지 않았습니다';
    } else if (err.message.includes('HTTP 오류')) {
      message = '서울 공개데이터 API 서버 오류';
    } else if (err.message.includes('API 오류')) {
      message = err.message;
    }

    return res.status(500).json({ success: false, message });
  }
});

/**
 * GET /api/subway
 * 시뮬레이션된 도착 정보 반환
 * 
 * 쿼리 파라미터:
 *   ?lineId=1001  – 노선 ID로 필터링
 *   ?station=강남 – 역 이름으로 필터링
 */
app.get('/api/subway', (req, res) => {
  try {
    const { lineId, station } = req.query;

    let stations;
    if (lineId) {
      stations = stationService.getByLine(lineId);
    } else if (station) {
      stations = stationService.getByName(station);
    } else {
      stations = stationService.getAll();
    }

    // 샘플 도착 정보 생성
    const data = stations.map(s => ({
      trainNo: `${s.subway_id}K${Math.floor(Math.random() * 900) + 100}`,
      subwayId: s.subway_id,
      statnId: s.station_id,
      statnNm: s.station_name,
      lineName: s.line_name,
      barvlDt: String(Math.floor(Math.random() * 180) + 30),
      updnLine: Math.random() > 0.5 ? '상행' : '하행'
    }));

    return res.json({ success: true, data });
  } catch (err) {
    console.error('/api/subway 오류 발생:', err);
    return res.status(500).json({ success: false, message: '서버 내부 오류' });
  }
});

/**
 * GET /health
 * 헬스 체크 엔드포인트
 */
app.get('/health', (_req, res) => {
  res.json({ status: '정상' });
});

/**
 * GET /
 * API 정보 조회
 */
app.get('/', (_req, res) => {
  res.json({
    name: '서울 지하철 실시간 추적 시스템 API',
    version: '1.0.0',
    endpoints: [
      'GET /api/stations - 전체 역 조회',
      'GET /api/stations?line=1001 - 특정 노선 역 조회',
      'GET /api/stations?name=강남 - 역 이름 검색',
      'GET /api/realtime - 실시간 도착정보',
      'GET /api/realtime?limit=50 - 제한된 개수의 실시간 도착정보',
      'GET /api/subway - 샘플 도착 정보',
      'GET /health - 헬스 체크'
    ]
  });
});

module.exports = app;