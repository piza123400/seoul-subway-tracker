'use strict';

const path = require('path');
const fs = require('fs');

/**
 * ========================================
 * 서울 지하철 역 데이터 서비스
 * ========================================
 * 
 * 이 모듈은 stations.json 파일에서 역 데이터를 로드하고
 * 다양한 방식으로 역 정보를 조회할 수 있는 기능을 제공합니다.
 */

// 역 데이터 파일 경로 설정
const filePath = path.join(__dirname, '../../data/stations.json');

// 역 데이터 파일 로드 및 파싱
let stations = [];
try {
  const data = fs.readFileSync(filePath, 'utf8');
  const parsed = JSON.parse(data);
  stations = parsed.stations || [];
  console.log(`✅ 역 데이터 로드 완료: ${stations.length}개 역`);
} catch (err) {
  console.error('❌ 역 데이터 로드 오류:', err.message);
  stations = [];
}

/**
 * 모든 역 조회
 * 
 * @description
 * 등록된 모든 역의 정보를 반환합니다.
 * 400개 이상의 서울 지하철 역 정보를 포함합니다.
 * 
 * @returns {Array} 전체 역 목록
 *                  각 항목: { subway_id, station_id, station_name, line_name }
 * 
 * @example
 * const allStations = getAll();
 * console.log(allStations.length); // 400+
 */
function getAll() {
  return stations;
}

/**
 * 노선 ID로 역 필터링
 * 
 * @description
 * 지정된 노선에 속한 모든 역을 조회합니다.
 * 노선 ID는 "1001" (1호선), "1002" (2호선) 형식입니다.
 * 
 * @param {string} subwayId - 노선 ID (예: "1001", "1002", ... "1009")
 * @returns {Array} 해당 노선의 역 목록
 *                  예: 1호선은 177개 역 반환
 * 
 * @example
 * // 1호선의 모든 역 조회
 * const line1Stations = getByLine('1001');
 * console.log(line1Stations.length); // 177
 * 
 * @example
 * // 2호선의 모든 역 조회
 * const line2Stations = getByLine('1002');
 */
function getByLine(subwayId) {
  // subwayId를 문자열로 변환하여 비교
  const lineId = String(subwayId);
  const filtered = stations.filter(s => s.subway_id === lineId);
  
  if (filtered.length === 0) {
    console.warn(`⚠️ 노선 ${lineId}를(을) 찾을 수 없습니다`);
  }
  
  return filtered;
}

/**
 * 역 이름으로 검색
 * 
 * @description
 * 역 이름에 포함된 한글 문자로 검색합니다.
 * 부분 검색을 지원하므로 "강남"으��� 검색하면
 * "강남", "강남구청" 등 모든 결과를 반환합니다.
 * 
 * @param {string} name - 검색할 역 이름 (한글)
 * @returns {Array} 검색 결과 역 목록
 *                  여러 노선의 같은 이름 역도 모두 반환
 * 
 * @example
 * // "강남"이 포함된 역 모두 검색
 * const results = getByName('강남');
 * // 반환: 강남, 강남구청 (2호선, 5호선, 7호선, 분당선 등)
 * 
 * @example
 * // "종로"가 포함된 역 모두 검색
 * const results = getByName('종로');
 * // 반환: 종로3가, 종로5가, 종로6가 등
 */
function getByName(name) {
  // 입력값 정제 (앞뒤 공백 제거)
  const query = name.trim();
  
  // 입력값 검증
  if (!query) {
    console.warn('⚠️ 검색어가 입력되지 않았습니다');
    return [];
  }
  
  // 역 이름에 검색어가 포함된 역만 필터링
  const filtered = stations.filter(s => 
    s.station_name.includes(query)
  );
  
  if (filtered.length === 0) {
    console.warn(`⚠️ 검색 결과 없음: "${query}"`);
  } else {
    console.log(`✅ 검색 완료: "${query}" - ${filtered.length}개 역 발견`);
  }
  
  return filtered;
}

/**
 * 역 ID로 특정 역 조회 (추가 기능)
 * 
 * @description
 * 역 ID를 사용하여 정확히 하나의 역을 조회합니다.
 * 역 ID는 고유한 값입니다.
 * 
 * @param {string} stationId - 역 ID (예: "1001000100")
 * @returns {Object|null} 역 정보 또는 null
 * 
 * @example
 * const station = getById('1001000100');
 * console.log(station.station_name); // "소요산"
 */
function getById(stationId) {
  const station = stations.find(s => s.station_id === String(stationId));
  
  if (!station) {
    console.warn(`⚠️ 역 ID를 찾을 수 없습니다: ${stationId}`);
  }
  
  return station || null;
}

/**
 * 특정 노선의 역 개수 조회 (추가 기능)
 * 
 * @description
 * 지정된 노선에 몇 개의 역이 있는지 반환합니다.
 * 
 * @param {string} subwayId - 노선 ID
 * @returns {number} 해당 노선의 역 개수
 * 
 * @example
 * const count = getCountByLine('1001');
 * console.log(count); // 177
 */
function getCountByLine(subwayId) {
  return getByLine(subwayId).length;
}

/**
 * 모든 노선 목록 조회 (추가 기능)
 * 
 * @description
 * 데이터에 포함된 모든 노선의 ID와 이름을 반환합니다.
 * 
 * @returns {Array} 노선 목록
 *                  각 항목: { id, name, count }
 * 
 * @example
 * const lines = getAllLines();
 * lines.forEach(line => {
 *   console.log(`${line.name}: ${line.count}개 역`);
 * });
 */
function getAllLines() {
  const lineMap = new Map();
  
  // 모든 역을 순회하며 노선별로 그룹화
  stations.forEach(station => {
    const lineId = station.subway_id;
    const lineName = station.line_name;
    
    if (!lineMap.has(lineId)) {
      lineMap.set(lineId, {
        id: lineId,
        name: lineName,
        count: 0
      });
    }
    
    const line = lineMap.get(lineId);
    line.count++;
  });
  
  // Map을 배열로 변환하고 정렬
  return Array.from(lineMap.values())
    .sort((a, b) => {
      // 숫자로 정렬
      return parseInt(a.id) - parseInt(b.id);
    });
}

/**
 * 데이터 통계 조회 (추가 기능)
 * 
 * @description
 * 전체 역 데이터의 통계 정보를 반환합니다.
 * 
 * @returns {Object} 통계 정보
 *                   { totalStations, totalLines, ... }
 */
function getStatistics() {
  const lines = getAllLines();
  
  return {
    totalStations: stations.length,
    totalLines: lines.length,
    lines: lines,
    lastUpdated: new Date().toISOString()
  };
}

// ========================================
// 모듈 내보내기
// ========================================

module.exports = {
  // 기본 기능
  getAll,           // 전체 역 조회
  getByLine,        // 노선별 역 조회
  getByName,        // 역 이름 검색
  
  // 추가 기능
  getById,          // 역 ID로 조회
  getCountByLine,   // 노선별 역 개수
  getAllLines,      // 모든 노선 목록
  getStatistics     // 데이터 통계
};

// ========================================
// 초기화 로그
// ========================================

console.log('📍 역 데이터 서비스 초기화 완료');
console.log(`   • 총 ${stations.length}개 역 로드됨`);
console.log(`   • 총 ${getAllLines().length}개 노선 포함`);